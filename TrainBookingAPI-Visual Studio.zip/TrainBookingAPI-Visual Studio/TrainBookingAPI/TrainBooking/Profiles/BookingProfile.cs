﻿using TrainBooking.DTO;
using AutoMapper;
using TrainBooking.Model;

namespace TrainBooking.Profiles
{
    public class BookingProfile:Profile
    {
        public BookingProfile()
        {
            CreateMap<Booking, BookingReadDTO>();
            CreateMap<BookingCreateDTO, Booking>();
        }
    }
}
