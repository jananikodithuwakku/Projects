﻿using System.Collections.Generic;
using System.Linq;
using TrainBooking.Model;


namespace TrainBooking.Data
{
    public class PassengerRepository
    {
        private readonly AppDBContext _dbContext; 

        public PassengerRepository(AppDBContext context)
        {
            _dbContext = context;
        }

        public bool CreatePassenger(Passenger passenger)
        {
            if (passenger != null)
            {
                _dbContext.Passengers.Add(passenger);
                return Save();
            }
            else
            {
                return false;
            }
        }

        public bool Save()
        {
            int count = _dbContext.SaveChanges();
            return count > 0;
        }

        public bool UpdatePassenger(Passenger passenger)
        {
            _dbContext.Passengers.Update(passenger);
            return Save();
        }

        public bool RemovePassenger(Passenger passenger)
        {
            _dbContext.Passengers.Remove(passenger);
            return Save();
        }

        public Passenger GetPassenger(int id)
        {
            return _dbContext.Passengers.FirstOrDefault(passenger => passenger.PassengerId == id);
        }

        public IEnumerable<Passenger> GetPassengers()
        {
            return _dbContext.Passengers.ToList();
        }
    }
}
