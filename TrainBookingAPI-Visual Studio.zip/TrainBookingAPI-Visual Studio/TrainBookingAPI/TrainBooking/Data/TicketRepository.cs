﻿using Microsoft.EntityFrameworkCore;
using TrainBooking.Model;

namespace TrainBooking.Data
{
    public class TicketRepository
    {
        private readonly AppDBContext dbContext; 
        public TicketRepository(AppDBContext context)
        {
            dbContext = context;
        }

        public bool CreateTicket(Ticket ticket)
        {
            if (ticket != null)
            {
                dbContext.tickts.Add(ticket);
                return Save();
            }
            else
            {
                return false;
            }
        }

        public bool Save()
        {
            int count = dbContext.SaveChanges();
            return count > 0;
        }

        public bool UpdateTicket(Ticket ticket)
        {
            dbContext.tickts.Update(ticket);
            return Save();
        }


        public Ticket GetTicket(int id)
        {
            return dbContext.tickts.FirstOrDefault(ticket => ticket.TicketId == id);
        }

        public IEnumerable<Ticket> GetTickets()
        {
            return dbContext.tickts.ToList();
        }
    }
}
