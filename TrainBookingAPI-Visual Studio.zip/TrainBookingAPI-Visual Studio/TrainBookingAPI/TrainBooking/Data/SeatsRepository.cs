﻿using Microsoft.EntityFrameworkCore;
using TrainBooking.Model;

namespace TrainBooking.Data
{
    public class SeatsRepository
    {
        private readonly AppDBContext _context;

        public SeatsRepository(AppDBContext context)
        {
            _context = context;
        }

        public bool CreateSeat(Seats seat)
        {
            try
            {
                _context.seats.Add(seat);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                
                return false;
            }
        }

        public bool UpdateSeat(Seats seat)
        {
            try
            {
                _context.seats.Update(seat);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                
                return false;
            }
        }

        public bool RemoveSeat(Seats seat)
        {
            try
            {
                _context.seats.Remove(seat);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                
                return false;
            }
        }

        public Seats GetSeat(int seatNumber)
        {
            return _context.seats.FirstOrDefault(s => s.SeatNumber == seatNumber);
        }

        public IEnumerable<Seats> GetAllSeats()
        {
            return _context.seats.ToList();
        }
    }
}
