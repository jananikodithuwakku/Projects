﻿namespace TrainBooking.DTO
{
    public class TicketCreateDTO
    {
        public int BookingId { get; set; }
        public int SeatNumber { get; set; }
        public decimal Price { get; set; }
        public string BookingTime { get; set; }
        public string DepartureTime { get; set; }
        public string ArrivalTime { get; set; }
    }
}
