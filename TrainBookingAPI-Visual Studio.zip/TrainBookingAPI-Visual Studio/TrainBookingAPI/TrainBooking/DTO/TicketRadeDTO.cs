﻿namespace TrainBooking.DTO
{
    public class TicketRadeDTO
    {
        public int TicketId { get; set; }
        public int BookingId { get; set; }
        public int SeatNumber { get; set; }
        public decimal Price { get; set; }
        public string BookingTime { get; set; }
        public string DepartureTime { get; set; }
        public string ArrivalTime { get; set; }
    }
}
