﻿using TrainBooking.Model;

namespace TrainBooking.DTO
{
    public class TrainCreateDTO
    {
        public int StartStation { get; set; }
        public string EndStation { get; set; }
        public string DepartureTime { get; set; }
        public string ArrivalTime { get; set; }
        public List<Seats> Seats { get; set; }
        
    }
}
