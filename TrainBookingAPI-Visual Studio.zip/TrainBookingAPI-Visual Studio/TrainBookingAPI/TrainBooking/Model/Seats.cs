﻿using System.ComponentModel.DataAnnotations;

namespace TrainBooking.Model
{
    public class Seats
    {
        [Key]
        public int SeatNumber { get; set; }

        [Required]
        public bool IsAvailable { get; set; }


    }
}
    

