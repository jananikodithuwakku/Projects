﻿using System.ComponentModel.DataAnnotations;

namespace TrainBooking.Model
{
    public class Booking
    {
        [Key]
        public int BookingId { get; set; }

        [Required]
        public string PassengerName { get; set; } = "Not Given";

        [Required]
        public string NICNumber { get; set; } = "Not Given";

        [Required]
        public string BookingTime { get; set; } = "Not Given";

        [Required]
        public bool IsConfirmed { get; set; }

        public List<Ticket> Tickets { get; set; }
    }
}
