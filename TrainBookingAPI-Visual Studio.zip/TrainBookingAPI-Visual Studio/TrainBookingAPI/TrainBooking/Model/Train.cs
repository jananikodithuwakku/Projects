﻿using System.ComponentModel.DataAnnotations;

namespace TrainBooking.Model
{
    public class Train
    {
        [Key]
        public int TrainId { get; set; } 

        [Required]
        public string StartStation { get; set; } = "Not Given";

        [Required]
        public string EndStation { get; set; } = "Not Given";

        [Required]
        public string DepartureTime { get; set; } = "Not Given";

        [Required]
        public string ArrivalTime { get; set; } = "Not Given";
        [Required]
        public List<Seats> Seats { get; set; }
        
       
    }
}
    

