﻿using System.ComponentModel.DataAnnotations;

namespace WebTrainBooking.Model
{
    public class Booking
    {
        public int BookingId { get; set; }
        public string PassengerName { get; set; } 
        public string NICNumber { get; set; } 
        public string BookingTime { get; set; }
        public bool IsConfirmed { get; set; }
    }
}
