using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebTrainBooking.Model;


namespace WebTrainBooking.Pages
{
    public class TrainModel : PageModel
    {
        public List<Train> trains { get; set; } = new List<Train>();
        public List<Train> FilteredTrains { get; set; } = new List<Train>();

        public async Task<IActionResult> OnGet(string searchQuery)
        {
            string url = "https://localhost:44371/api/Train";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    trains = await response.Content.ReadAsAsync<List<Train>>();
                    if (!string.IsNullOrEmpty(searchQuery))
                    {
                        FilteredTrains = trains
                            .Where(t => t.StartStation.ToLower().Contains(searchQuery.ToLower()) ||
                                        t.EndStation.ToLower().Contains(searchQuery.ToLower()))
                            .ToList();
                    }
                    else
                    {
                        FilteredTrains = trains;
                    }
                }
            }
            return Page();
        }
    }
}
