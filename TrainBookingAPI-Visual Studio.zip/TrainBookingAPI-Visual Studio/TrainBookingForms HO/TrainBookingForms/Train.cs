﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Web.Script.Serialization;

namespace TrainBookingForms
{
    public partial class Train : Form
    { 
        int trainId;
        public Train()
        {
            InitializeComponent();
        }
       
        private void button2_Click(object sender, EventArgs e)
        {
            string url = "https://localhost:44371/api/Train" + trainId; 
            HttpClient client = new HttpClient();
            TrainB train = new TrainB();
            train.TrainId = trainId;
            train.StartStation = textBox2.Text;
            train.EndStation = textBox3.Text;
            train.DepartureTime = textBox4.Text;
            train.ArrivalTime = textBox5.Text;
            string data = (new JavaScriptSerializer()).Serialize(train);
            var content = new
                StringContent(data, UnicodeEncoding.UTF8, "application/json");
            var res = client.PutAsync(url, content).Result;
            if (res.IsSuccessStatusCode)
            {
                MessageBox.Show("Train details were updated successfully.");
            }
            else
            {
                MessageBox.Show("Failed to update train details.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string url = "https://localhost:44371/api/Train" + trainId;
            HttpClient client = new HttpClient();
            TrainB train = new TrainB();
            train.TrainId = trainId;
            train.StartStation = textBox2.Text;
            train.EndStation = textBox3.Text;
            train.DepartureTime = textBox4.Text;
            train.ArrivalTime = textBox5.Text;
            string data = (new JavaScriptSerializer()).Serialize(train);
            var content = new
                StringContent(data, UnicodeEncoding.UTF8, "application/json");
            var res = client.PutAsync(url, content).Result;
            if (res.IsSuccessStatusCode)
            {
                MessageBox.Show("Train details were added successfully.");
            }
            else
            {
                MessageBox.Show("Failed to add train details.");
            }
        }

        private void Train_Load(object sender, EventArgs e)
        {
            LoadTrain();
        }

        private void DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                textBox1.Text = DGV.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox2.Text = DGV.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox3.Text = DGV.Rows[e.RowIndex].Cells[4].Value.ToString();
                textBox4.Text = DGV.Rows[e.RowIndex].Cells[5].Value.ToString();
                textBox5.Text = DGV.Rows[e.RowIndex].Cells[6].Value.ToString();
                trainId = Convert.ToInt32(DGV.Rows[e.RowIndex].Cells[2].Value.ToString());

            }
            else if (e.ColumnIndex == 1)
            {
                trainId = Convert.ToInt32(DGV.Rows[e.RowIndex].Cells[2].Value.ToString());
                string url = "https://localhost:44371/api/Train" + trainId;
                HttpClient client = new HttpClient();
                DialogResult result = MessageBox.Show
                    ("Are you sure you want to delete?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    var res = client.DeleteAsync(url).Result;
                    if (res.IsSuccessStatusCode)
                    {
                        LoadTrain();
                    }
                }
            }
        }
        public void LoadTrain()
        {
            string url = "https://localhost:44371/api/Train";
            WebClient client = new WebClient();
            client.Headers["content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.DownloadString(url);
            DGV.DataSource = null;
            DGV.DataSource = (new JavaScriptSerializer()).
                Deserialize<List<TrainB>>(json);
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
    public class TrainB
    {
        public int TrainId { get; set; }
        public string StartStation { get; set; } 
        public string EndStation { get; set; } 
        public string DepartureTime { get; set; }
        public string ArrivalTime { get; set; }
    }
}
