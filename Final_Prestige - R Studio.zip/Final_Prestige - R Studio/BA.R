attach(Prestige_New)
data<-read.csv("Prestige_New.CSV")


#.................................Task 03.................................

summary_income <- summary(Prestige_New$income)

# Mode function (custom implementation)
get_mode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

# Mode of income
mode_income <- get_mode(Prestige_New$income)

# Output the results
result <- data.frame(
  Minimum_Income = min(Prestige_New$income),
  Maximum_Income = max(Prestige_New$income),
  Mean_Income = mean(Prestige_New$income),
  Median_Income = median(Prestige_New$income),
  Mode_Income = mode_income
)

result

#.................................Task 04.................................

# Summary statistics for prestige, education, and income
summary_statistics <- summary(Prestige_New[c("prestige", "education", "income")])

summary_statistics


#.................................Task 05.................................

mean_education <- mean(Prestige_New$education, na.rm = TRUE)
sd_education <- sd(Prestige_New$education, na.rm = TRUE)

mean_income <- mean(Prestige_New$income, na.rm = TRUE)
sd_income <- sd(Prestige_New$income, na.rm = TRUE)

mean_prestige <- mean(Prestige_New$prestige, na.rm = TRUE)
sd_prestige <- sd(Prestige_New$prestige, na.rm = TRUE)

# Print mean and standard deviation values
print(paste("Prestige Mean:", mean_prestige))
print(paste("Prestige Standard Deviation:", sd_prestige))
print("")

print(paste("Education Mean:", mean_education))
print(paste("Education Standard Deviation:", sd_education))
print("")

print(paste("Income Mean:", mean_income))
print(paste("Income Standard Deviation:", sd_income))
print("")

# Prestige
hist(Prestige_New$prestige, main = "Prestige Distribution",
     xlab = "Prestige", ylab = "Frequency", probability = TRUE)
curve(dnorm(x, mean = mean_prestige, sd = sd_prestige), 
      add = TRUE, col = "green")

# Education
hist(Prestige_New$education, main = "Education Distribution",
     xlab = "Education", ylab = "Frequency", probability = TRUE)
curve(dnorm(x, mean = mean_education, sd = sd_education), 
      add = TRUE, col = "blue")

# Income
hist(Prestige_New$income, main = "Income Distribution",
     xlab = "Income", ylab = "Frequency", probability = TRUE)
curve(dnorm(x, mean = mean_income, sd = sd_income), 
      add = TRUE, col = "red")



#.................................Task 06.................................

# Perform ANOVA test
anova_result <- aov(prestige ~ type, data = Prestige_New)

# Summary of ANOVA test
summary(anova_result)

# Plot the distribution of prestige scores by type of occupation
boxplot(prestige ~ type, data = Prestige_New, 
        main = "Prestige by Type of Occupation",
        xlab = "Type of Occupation", ylab = "Prestige")

#.................................Task7.................................

# Shapiro-Wilk normality test 
shapiro.test(Prestige_New$prestige)

# Anderson-Darling normality test 
library(nortest)
ad.test(Prestige_New$prestige)

# Lilliefors (Kolmogorov-Smirnov) normality test 
library(nortest)
lillie.test(Prestige_New$prestige)

# Shapiro-Wilk normality test 
shapiro.test(Prestige_New$education)

# Anderson-Darling normality test 
ad.test(Prestige_New$education)

# Lilliefors (Kolmogorov-Smirnov) normality test 
lillie.test(Prestige_New$education)

# Pearson's correlation coefficient test 
cor.test(Prestige_New$prestige, Prestige_New$education)

# Scatter plot 
plot(Prestige_New$prestige, Prestige_New$education, 
     xlab = "Prestige", ylab = "Education",col = "green",
     main = "Scatter Plot of Prestige and Education")

#.................................Task 08.................................


# Shapiro-Wilk normality test 
shapiro.test(Prestige_New$prestige)

# Anderson-Darling normality test 
library(nortest)
ad.test(Prestige_New$prestige)

# Lilliefors (Kolmogorov-Smirnov) normality test 
library(nortest)
lillie.test(Prestige_New$prestige)

# Shapiro-Wilk normality test
shapiro.test(Prestige_New$income)

# Anderson-Darling normality test 
ad.test(Prestige_New$income)

# Lilliefors (Kolmogorov-Smirnov) normality test 
lillie.test(Prestige_New$income)

# Pearson's correlation coefficient test 
cor.test(Prestige_New$prestige, Prestige_New$income)

# Scatter plot 
plot(Prestige_New$prestige, Prestige_New$income, 
     xlab = "Prestige", ylab = "Income",col = "green",
     main = "Scatter Plot of Prestige and Income")






#.................................Task 9.................................

attach(Prestige_New)
install.packages("plyr")
library(plyr)
Prestige_New$type<-revalue(type,c(prof=3,bc=2,wc=1))
write.csv(Prestige_New,"Prestige2.csv")
detach(Prestige_New)
attach(Prestige2)
detach(Prestige2_new)
ad.test(type)
lillie.test(type)
shapiro.test(type)
summary(type)

#Scatter plot
plot(x = type, y = prestige, xlab = "Type",
     ylab = "Prestige", main = "Scatter Plot", col= "green")

correlation <- cor(Prestige2$type, Prestige2$prestige)
print(correlation)
#cor
correlation <- cor(Prestige2$type, Prestige2$prestige, use = "complete.obs")
print(correlation)
# Summary of correlation
summary(correlation)

# Perform multiple linear regression
my_model <- lm(prestige ~ education + income, data = Prestige2)
print(summary(my_model))

# Predicted values
predicted_values <- predict(my_model)
print(predicted_values)



#.................................Task 10.................................


# Simple Regression analysis 
# prestige vs education

attach(Prestige2_new)

my_model_1<-lm(prestige~education) 
my_model_1
summary(my_model_1)

# prestige vs income

my_model_2<-lm(prestige~income) 
my_model_2
summary(my_model_2)

# prestige vs type

my_model_3<-lm(prestige~type) 
my_model_3
summary(my_model_3)

# graph analysis 
install.packages("Rcmdr")
library(Rcmdr)

# My_model1
# Scatterplot of prestige vs education
plot(Prestige2$education, Prestige2$prestige, 
     xlab = "Education", ylab = "Prestige", 
     main = "Scatterplot of Prestige vs Education", col = "red", pch = 16)
abline(my_model_1, col = "blue")  # Add regression line

# Scatterplot of prestige vs income
plot(Prestige2$income, Prestige2$prestige, 
     xlab = "Income", ylab = "Prestige", 
     main = "Scatterplot of Prestige vs Income", col = "red", pch = 16)
abline(my_model_2, col = "blue")  # Add regression line

# Scatterplot of prestige vs type
plot(Prestige2$type, Prestige2$prestige, 
     xlab = "Occupation Type", ylab = "Prestige", 
     main = "Scatterplot of Prestige vs Type", col = "red", pch = 16)
abline(my_model_3, col = "blue")  # Add regression line

# Multi-linear Regression analysis 
my_model_4 <- lm(prestige ~ education + income + type, data = Prestige2)
summary(my_model_4)










